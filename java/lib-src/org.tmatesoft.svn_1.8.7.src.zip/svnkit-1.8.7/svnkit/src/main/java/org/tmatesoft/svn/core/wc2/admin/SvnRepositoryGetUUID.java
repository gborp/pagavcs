package org.tmatesoft.svn.core.wc2.admin;

import org.tmatesoft.svn.core.wc2.SvnOperationFactory;


public class SvnRepositoryGetUUID extends SvnRepositoryOperation<String> {

    public SvnRepositoryGetUUID(SvnOperationFactory factory) {
        super(factory);
    }
}
