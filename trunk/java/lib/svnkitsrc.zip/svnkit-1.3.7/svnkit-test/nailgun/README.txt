To compile the nailgun client on systems with gcc and make,
type "make" in the project directory.

Documentation is under development.  For up-to-date information,
including a "Quick Start" guide, visit:

	http://www.martiansoftware.com/nailgun
	
Javadocs for NailGun are in the "docs/api" directory with the
source distribution, and are also available at the above website.
